<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Homepage</title>

    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
    <link rel="shortcut icon" href="images/kxp_fav.png" type="image/x-icon">
    <link rel='stylesheet' type='text/css' href='./styling/bootstrap.min.css'>
    <link rel="stylesheet" href="./styling/dstyle.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    
</head>

<body>
<script src="./styling/bootstrap.bundle.min.js"></script>

    <div class="sidebar close">
        <a href="#" class="logo-box">
            <i class='bx bxl-xing'></i>
            <div class="logo-name">QREvent</div>
        </a>

        <ul class="sidebar-list">
            <li>
                <div class="title">
                    <a href="dashboard.php" class="link">
                        <i class='bx bx-grid-alt'></i>
                        <span class="name">Dashboard</span>
                    </a>
                </div>
                <div class="submenu">
                    <a href="dashboard.php" class="link submenu-title">Dashboard</a>
                </div>
            </li>
            <li class="dropdown">
                <div class="title">
                    <a href="students.php" class="link">
                        <i class='bx bx-book-alt'></i>
                        <span class="name">Entries</span>
                    </a>
                    <i class='bx bxs-chevron-down'></i>
                </div>
                <div class="submenu">
                    <a href="students.php" class="link submenu-title">Students List</a>
                </div>
            </li>

            <li>
                <div class="title">
                    <a href="newevent.php" class="link">
                        <i class='bx bx-line-chart'></i>
                        <span class="name">New Event</span>
                    </a>
                </div>
                <div class="submenu">
                    <a href="newevent.php" class="link submenu-title">Add Event</a>
                </div>
            </li>

            <li>
                <div class="title">
                    <a href="newstudent.php" class="link">
                        <i class='bx bx-line-chart'></i>
                        <span class="name">Add Student</span>
                    </a>
                </div>
                <div class="submenu">
                    <a href="newstudent.php" class="link submenu-title">Add Student</a>
                </div>
            </li>
            <li>
                <div class="title">
                    <a href="eventAttendance.php" class="link">
                        <i class='bx bx-history'></i>
                        <span class="name">Record Event Attendance</span>
                    </a>
                </div>
                <div class="submenu">
                    <a href="eventAttendance.php" class="link submenu-title">Record Event Attendance</a>
                </div>
            </li>
        </ul>
    </div>


    <section class="home">
        <div class="toggle-sidebar">
            <i class='bx bx-menu'></i>
        </div>
        <div class="d-flex justify-content-left">
                    <?php 
                        require_once "./backend/db/db_connection.php";
                        $eventName = $_GET['eventName'];
                        $sql_query = "SELECT * FROM event WHERE EVENT_NAME = '{$eventName}'";
                        if ($result = $con ->query($sql_query)) {
                            while ($row = $result -> fetch_assoc()) { 
                                $EVENT_NAME = $row['EVENT_NAME'];
                                $EVENT_DETAILS = $row['EVENT_DETAILS'];
                                $EVENT_ORGANIZER = $row['EVENT_ORGANIZER'];
                                $EVENT_DATE = $row['EVENT_DATE'];
                                $EVENT_TIME = $row['EVENT_TIME'];
                                $EVENT_VENUE = $row['EVENT_VENUE'];
                    ?>
            <div class="card" style="width: 18rem;margin: 15px">
                <img src="./images/event<?php echo(rand(1,8)); ?>.png" class="card-img-top" alt="Image Here">
                <div class="card-body">
                </div>
            </div>
            <div class="d-flex flex-column mb-8">                    
                <div class="col-md-8" style="margin: 15px">     
                
                <div class="card" style="width: 18rem;">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item" aria-current="true">Event Name: <span class="badge text-bg-success rounded-pill"><?php echo $EVENT_NAME; ?></span></li>
                        <li class="list-group-item" aria-current="true">Details: <span class="badge text-bg-success rounded-pill"><?php echo $EVENT_DETAILS; ?></span></li>
                        <li class="list-group-item" aria-current="true">Organizer: <span class="badge text-bg-success rounded-pill"><?php echo $EVENT_ORGANIZER; ?></span></li>
                        <li class="list-group-item" aria-current="true">Date: <span class="badge text-bg-success rounded-pill"><?php echo $EVENT_DATE; ?></span></li>
                        <li class="list-group-item" aria-current="true">Time: <span class="badge text-bg-success rounded-pill"><?php echo $EVENT_TIME; ?></span></li>
                        <li class="list-group-item" aria-current="true">Venue: <span class="badge text-bg-success rounded-pill"><?php echo $EVENT_VENUE; ?></span></li>
                    </ul>
                </div>
                
                    <?php
                                    } 
                                } 
                    ?>
                </div> 
                <div style="margin: 15px"> <h4>Student Attendance List</h4> </div>
                <div class="col-md-12" style="margin: 15px"> 
                           
                    <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Student Name</th>
                                    <th scope="col">Grade</th>
                                    <th scope="col">Strand</th>
                                    <th scope="col">Section</th>
                                    <th scope="col">Attendance</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php 
                        require_once "./backend/db/db_connection.php";
                        $sql_query = "SELECT * FROM student INNER JOIN event_attendance ON student.STUDENT_ID=event_attendance.STUDENT_ID WHERE event_attendance.EVENT_NAME='{$eventName}';";
                        if ($result = $con ->query($sql_query)) {
                            while ($row = $result -> fetch_assoc()) { 
                                $FIRST_NAME = $row['FIRST_NAME'];
                                $LAST_NAME = $row['LAST_NAME'];
                                $MIDDLE_NAME = $row['MIDDLE_NAME'];
                                $SECTION = $row['SECTION'];
                                $STRAND = $row['STRAND'];
                                $GRADE = $row['GRADE'];
                    ?> 
                                <tr>
                                    <th><?php echo $FIRST_NAME, " ", $MIDDLE_NAME, " ", $LAST_NAME; ?></th>
                                    <td><?php echo $GRADE; ?></td>
                                    <td><?php echo $STRAND; ?></td>
                                    <td><?php echo $SECTION; ?></td>
                                    <td><i class="fa fa-check-circle" style="color:green"></i></td>
                                </tr>
                            </tbody>
                            <?php
                                    } 
                                } 
                    ?>
                    </table>
                                
                
                    
                </div>  
                <div style="margin: 15px"><a href="./eventAttendance.php" class="btn btn-danger stretched-link">Record Event Attendance</a></div>
            </div> 
        </div>
    </section>
    <div class="main--content">
    </div>
    </div>
    

    <script src="dmain.js"></script>

    <a href="logout.php">Logout</a>
</body>

</html>