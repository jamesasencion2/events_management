<?php
include "./db/db_connection.php";         
session_start();
// foreach($_POST as $k=>$v) $p[$k] = mysql_real_escape_string($v);
if(isset($_POST['submit'])){
    $studentID = $_POST['studentID'];
    $firstName = $_POST['firstName'];
    $middleName = $_POST['middleName'];
    $lastName = $_POST['lastName'];
    $birthdate = $_POST['birthdate'];
    $gender = $_POST['gender'];
    $strand = $_POST['strand'];
    $grade = $_POST['grade'];
    $section = $_POST['section'];
    $sql = "INSERT INTO student(STUDENT_ID, FIRST_NAME,MIDDLE_NAME,LAST_NAME,BIRTHDATE,GENDER,STRAND,GRADE,SECTION) VALUES('{$studentID}','{$middleName}','{$middleName}','{$lastName}','{$birthdate}','{$gender}','{$strand}','{$grade}','{$section}')";
    if (mysqli_query($con, $sql)) {
        header("location: ../success_student.php");
    } else {
         echo "Something went wrong. Please try again later.";
    }

ob_clean();
}

?>